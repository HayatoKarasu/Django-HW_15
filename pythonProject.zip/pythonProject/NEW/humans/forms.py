from django import forms
from .models import Prof, Human
import re
from django.core.exceptions import ValidationError


class HumanForm(forms.ModelForm):

    def clean_fio(self):
        fio = self.cleaned_data['fio']
        if re.match(r'\d', fio):
            raise ValueError('ФИО не должно начинаться с цифр')
        return fio

    class Meta:
        model = Human
        #fields = '__all__'
        fields = ['fio', 'character', 'is_published', 'profession']
        widgets = {
            'fio': forms.TextInput(attrs={'class': 'form-control'}),
            'character': forms.Textarea(attrs={'class': 'form-control', 'rows': 5}),
            'profession': forms.Select(attrs={'class': 'form-control'})
        }

    #fio = forms.CharField(max_length=150, label='ФИО', widget=forms.TextInput(attrs={'class': 'form-control'}))
    #character = forms.CharField(label='Характеристика', required=False, widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 5}))
    #is_published = forms.BooleanField(label='Регистрация', initial=True)
    #profession = forms.ModelChoiceField(queryset=Prof.objects.all(), label='Профессия', empty_label='Выберите профессию', widget=forms.Select(attrs={'class': 'form-control'}))
