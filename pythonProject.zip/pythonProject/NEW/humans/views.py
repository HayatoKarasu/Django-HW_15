from django.shortcuts import render, get_object_or_404, redirect
from .models import Human, Prof
from .forms import HumanForm
from django.views.generic import ListView, DetailView, CreateView
from .utils import MyMixin
from django.contrib.auth.mixins import LoginRequiredMixin
from django.core.paginator import Paginator


class HomeHumans(ListView, MyMixin):
    model = Human
    context_object_name = 'humans'
    template_name = 'humans/home_humans_list.html'
    extra_context = {'title': 'Главная'}
    paginate_by = 3

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = 'Главная страница'
        return context

    def get_queryset(self):
        return Human.objects.filter(is_published=True).select_related('profession')


class HumansByProf(ListView, MyMixin):
    model = Human
    context_object_name = 'humans'
    template_name = 'humans/home_humans_list.html'
    allow_empty = False
    paginate_by = 2

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = Prof.objects.get(pk=self.kwargs['profession_id'])
        return context

    def get_queryset(self):
        return Human.objects.filter(profession_id=self.kwargs['profession_id'], is_published=True).select_related('profession')


class ViewHuman(DetailView):
    model = Human
    context_object_name = 'humans_item'
    template_name = 'humans/view_human.html'


class AddHuman(CreateView):
    form_class = HumanForm
    template_name = 'humans/add_humans.html'
    login_url = '/admin/'

# def index(request):
# humans = Human.objects.all()
# context = {
# 'humans': humans,
# 'title': 'Список людей',
# }
# return render(request, 'humans/index.html', context=context)


# def get_prof(request, profession_id):
# humans = Human.objects.filter(profession_id=profession_id)
# profes = Prof.objects.get(pk=profession_id)
# context = {
# 'humans': humans,
# 'profes': profes
# }
# return render(request, 'humans/prof.html', context=context)


# def view_human(request, human_id):
# human_item = Human.objects.get(pk=human_id)
# human_item = get_object_or_404(Human, pk=human_id)
# context = {
# 'human_item': human_item,
# }
# return render(request, 'humans/view_human.html', context=context)


# def add_humans(request):
# if request.method == 'POST':
# form = HumanForm(request.POST)
# if form.is_valid():
# humans = Human.objects.create(**form.cleaned_data)
# humans = form.save()
# return redirect(humans)
# else:
# form = HumanForm()
# return render(request, 'humans/add_humans.html', {'form': form})


#def test(request):
#    objects = ['john', 'paul', 'george', 'ringo', 'john2', 'paul2', 'george2', 'ringo2']
#   paginator = Paginator(objects, 2)
#   page_num = request.GET.get('page', 1)
#   page_objects = paginator.get_page(page_num)
#   return render(request, 'humans/test.html', {'page_obj': page_objects})
